# -*- coding: utf-8 -*-
__version__ = "1.8.3"
from .TwitchChannelPointsMiner import TwitchChannelPointsMiner

__all__ = [
    "TwitchChannelPointsMiner",
]
